package com.example.Train_Micro;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TrainRepository extends JpaRepository<Train, Long> {

    Train findByTrainNumber(String trainNumber); 
    
    @Query("SELECT t FROM Train t WHERE t.acCoaches > :minAcCoaches")
    List<Train> findTrainsWithACCoachesGreaterThan(int minAcCoaches);

    //Can add more custom queries

}
