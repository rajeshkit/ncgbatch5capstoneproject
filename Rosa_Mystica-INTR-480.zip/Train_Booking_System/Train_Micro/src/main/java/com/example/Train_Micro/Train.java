package com.example.Train_Micro;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "TRAIN")

public class Train {
    @Id
    @Column(name = "T_ID")
    private Long id;

    @Column(name = "T_NO")
    private String trainNumber;

    @Column(name = "T_NAME")
    private String trainName;

    @Column(name = "TOTAL_KMS")
    private int totalKms;

    @Column(name = "AC_COACHES")
    private int acCoaches;

    @Column(name = "AC_COACH_SEATS")
    private int acCoachTotalSeats;

    @Column(name = "SLEEPER_COACHES")
    private int sleeperCoaches;

    @Column(name = "SLEEPER_COACH_SEATS")
    private int sleeperCoachTotalSeats;

    @Column(name = "GENERAL_COACHES")
    private int generalCoaches;

    @Column(name = "GENERAL_COACH_SEATS")
    private int generalCoachTotalSeats;
}

}
