package com.example.Train_Micro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainMicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainMicroApplication.class, args);
	}

}
