package com.example.Train_Micro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
