package com.example.Schedule_Micro;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "SCHEDULE")

public class Schedule {
    @Id
    @Column(name = "S_ID")
    private Long id;
    @Column(name = "DEPARTURE_DATE_TIME")
    private LocalDateTime departureDateTime;

    @Column(name = "ARRIVAL_DATE_TIME")
    private LocalDateTime arrivalDateTime;

    @ManyToOne(fetch = FetchType.EAGER)
    private Train train;

    @ManyToOne(fetch = FetchType.EAGER)
    private Route route;
}

}
