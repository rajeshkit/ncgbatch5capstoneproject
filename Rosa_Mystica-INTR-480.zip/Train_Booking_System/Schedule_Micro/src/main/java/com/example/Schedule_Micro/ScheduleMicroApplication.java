package com.example.Schedule_Micro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScheduleMicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScheduleMicroApplication.class, args);
	}

}
