package com.example.Schedule_Micro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScheduleMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
