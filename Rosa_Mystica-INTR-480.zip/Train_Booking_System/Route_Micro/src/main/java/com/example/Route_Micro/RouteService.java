package com.example.Route_Micro;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RouteService {
    @Autowired
    private RouteRepository routeRepository;

    public List<Route> getAllRoutes() {
        return null;
    }

    public Route getRouteById(Long id) {
        return null;
    }

    public Route createRoute(Route route) {
        return null;
    }

    public Route updateRoute(Long id, Route route) {
        return null;
    }

    public boolean deleteRoute(Long id) {
        return false;
    }

}
