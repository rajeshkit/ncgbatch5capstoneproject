package com.example.Route_Micro;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "ROUTE")

public class Route {
    @Id
    @Column(name = "R_ID")
    private Long id;

    @Column(name = "R_source")
    private String source;

    @Column(name = "R_Destination")
    private String destination;

    @Column(name = "TOTAL_KMS")
    private int totalKms;

    @Column(name = "ESTIMATED_TRAVEL_TIME")
    private int estimatedTravelTime;

    @Column(name = "AVAILABLE")
    private boolean available;


}

}
