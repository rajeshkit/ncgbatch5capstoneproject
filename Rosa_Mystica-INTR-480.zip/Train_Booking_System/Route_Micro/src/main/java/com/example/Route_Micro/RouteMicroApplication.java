package com.example.Route_Micro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RouteMicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(RouteMicroApplication.class, args);
	}

}
