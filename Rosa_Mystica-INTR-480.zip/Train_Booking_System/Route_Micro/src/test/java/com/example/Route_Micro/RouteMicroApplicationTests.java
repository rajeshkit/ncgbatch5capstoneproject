package com.example.Route_Micro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RouteMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
