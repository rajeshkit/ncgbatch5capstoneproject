package com.altimetrik.Route;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RouteApplicationTests {

	@Test
	void contextLoads() {
	}

}
