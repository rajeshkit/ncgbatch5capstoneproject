package com.altimetrik.train.service;

import com.altimetrik.train.exception.TrainIdNotExistsException;
import com.altimetrik.train.model.Train;
import com.altimetrik.train.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class TrainServiceImp implements TrainService {
    @Autowired
    private TrainRepository trainRepository;
//    private RestTemplate restTemplate;

    public Train getTrainByNumber(int trainNumber) throws TrainIdNotExistsException {
//        return restTemplate.getForObject("http://train-microservice/train/" + trainNumber, Train.class);
        Optional<Train> pro = trainRepository.findById(trainNumber);

        if (pro.isEmpty()) {
            throw new TrainIdNotExistsException("NO TRAIN WITH THE ID!!! check the train ID");
        }

        return pro.get();
    }

    @Override
    public Train addTrain(Train train) {
        return trainRepository.save(train);
    }

    @Override
    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    @Override
    public Train updateTrain(Train train) throws TrainIdNotExistsException {
        if (getTrainByNumber(train.getTrainNumber()) != null) {
            return trainRepository.save(train);
        }
        return null;
    }

    @Override
    public String deleteTrainByNumber(int trainNumber) throws TrainIdNotExistsException {
        String message = "Train Does not exists to delete";
        Train t = getTrainByNumber(trainNumber);
        if (t != null) {
            trainRepository.deleteById(trainNumber);
            message = "train deleted successfully";
            return message;
        }
        return message;
    }


}
