package com.altimetrik.schedule.service;

public interface ScheduleService {
}
