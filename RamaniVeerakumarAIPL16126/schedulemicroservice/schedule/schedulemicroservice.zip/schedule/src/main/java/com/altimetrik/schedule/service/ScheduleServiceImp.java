package com.altimetrik.schedule.service;

public class ScheduleServiceImp implements ScheduleService{
}
