package com.altimetrik.schedule.repository;

public interface ScheduleRepository {
}
