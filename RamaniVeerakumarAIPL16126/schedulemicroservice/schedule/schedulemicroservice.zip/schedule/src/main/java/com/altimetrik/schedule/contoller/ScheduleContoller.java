package com.altimetrik.schedule.contoller;

public class ScheduleContoller {
}
