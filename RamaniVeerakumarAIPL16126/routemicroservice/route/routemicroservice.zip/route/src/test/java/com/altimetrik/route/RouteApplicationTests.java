package com.altimetrik.route;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RouteApplicationTests {

	@Test
	void contextLoads() {
	}

}
