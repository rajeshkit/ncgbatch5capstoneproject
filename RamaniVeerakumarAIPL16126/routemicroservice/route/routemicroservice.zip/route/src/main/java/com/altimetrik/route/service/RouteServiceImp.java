package com.altimetrik.route.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.altimetrik.route.repository.RouteRepository;
import com.altimetrik.route.model.Route;
import com.altimetrik.route.exception.RouteIdDoNotExitsException;

import java.util.List;
import java.util.Optional;

@Service
public class RouteServiceImp implements RouteService {
    @Autowired
    private RouteRepository routeRepository;
    @Override
    public Route getRouteById(int routeId) throws RouteIdDoNotExitsException {
        Optional<Route> pro = routeRepository.findById(routeId);

        if (pro.isEmpty()) {
            throw new RouteIdDoNotExitsException("NO ROUTE WITH THE ID!!! check the route ID");
        }

        return pro.get();
    }

    @Override
    public Route addRoute(Route route) {
        return routeRepository.save(route);
    }
    @Override
    public List<Route> getAllRoutes() {
        return routeRepository.findAll();
    }

    @Override
    public Route updateRoute(Route route) throws RouteIdDoNotExitsException {
        if (getRouteById(route.getRouteId()) != null) {
            return routeRepository.save(route);
        }
        return null;

    }

    @Override
    public String deleteRouteById(int routeId) throws RouteIdDoNotExitsException {
        String message = "Route Does not exists to delete";
        Route route = getRouteById(routeId);
        if (route != null) {
            routeRepository.deleteById(routeId);
            message = "route deleted successfully";
            return message;
        }
        return message;
    }


}
