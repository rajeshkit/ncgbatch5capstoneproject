import React from 'react'

const CheckAllTickets = () => {
  return (
    <div>CheckAllTickets</div>
  )
}

export default CheckAllTickets