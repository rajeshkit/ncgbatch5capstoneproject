import React from 'react'

const UpdateTicket = () => {
  return (
    <div>UpdateTicket</div>
  )
}

export default UpdateTicket