import React from 'react'

const CancelTicket = () => {
  return (
    <div>CancelTicket</div>
  )
}

export default CancelTicket