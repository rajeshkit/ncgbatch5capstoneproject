package com.schedulealtimetrik.schedulemicroservice.service;

import org.junit.jupiter.api.Test;

class ScheduleServiceImplTest {

    @Test
    void addSchedule() {
    }

    @Test
    void testAddSchedule() {
    }

    @Test
    void getAllSchedules() {
    }

    @Test
    void getScheduleById() {
    }

    @Test
    void updateSchedule() {
    }

    @Test
    void deleteScheduleById() {
    }
}