package com.routealtimetrik.routemicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoutemicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
