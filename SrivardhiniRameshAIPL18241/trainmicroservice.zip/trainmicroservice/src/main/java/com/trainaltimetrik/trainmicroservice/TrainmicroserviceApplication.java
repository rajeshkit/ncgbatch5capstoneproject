package com.trainaltimetrik.trainmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class TrainmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainmicroserviceApplication.class, args);
	}

}
