package com.altimetrikfinalproject.routemicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RouteMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RouteMicroserviceApplication.class, args);
	}

}
