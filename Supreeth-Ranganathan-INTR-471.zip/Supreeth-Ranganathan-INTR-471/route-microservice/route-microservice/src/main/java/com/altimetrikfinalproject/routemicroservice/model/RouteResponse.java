package com.altimetrikfinalproject.routemicroservice.model;

public class RouteResponse {
}
