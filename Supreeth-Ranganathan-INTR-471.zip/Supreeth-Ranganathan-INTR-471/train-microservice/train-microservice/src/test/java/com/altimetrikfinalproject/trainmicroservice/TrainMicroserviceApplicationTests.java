package com.altimetrikfinalproject.trainmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
