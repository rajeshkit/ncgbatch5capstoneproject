package com.altimetrikfinalproject.schedule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScheduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
