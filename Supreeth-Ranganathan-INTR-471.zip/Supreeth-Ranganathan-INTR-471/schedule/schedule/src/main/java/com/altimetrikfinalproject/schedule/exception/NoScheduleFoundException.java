package com.altimetrikfinalproject.schedule.exception;

public class NoScheduleFoundException extends Exception{
    public NoScheduleFoundException(){
        super("No schedule found");
    }
}
