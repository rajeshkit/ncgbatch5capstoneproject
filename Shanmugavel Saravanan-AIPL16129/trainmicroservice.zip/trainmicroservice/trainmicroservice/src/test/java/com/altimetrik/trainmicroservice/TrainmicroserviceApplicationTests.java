package com.altimetrik.trainmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainmicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
