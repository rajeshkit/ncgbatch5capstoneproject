package com.altimetrik.schedule.controller;

public class ScheduleControllerTest {
}