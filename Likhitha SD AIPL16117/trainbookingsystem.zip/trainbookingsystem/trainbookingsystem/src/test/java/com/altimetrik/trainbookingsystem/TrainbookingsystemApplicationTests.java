package com.altimetrik.trainbookingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainbookingsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
