package com.altimetrik.schedule.model;

public class Train {
}
