package com.altimetrik.schedule.service;

public class ScheduleServiceImplTest {
}
