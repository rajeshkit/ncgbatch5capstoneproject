package com.altimetrik.trainroute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainrouteApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainrouteApplication.class, args);
	}

}
