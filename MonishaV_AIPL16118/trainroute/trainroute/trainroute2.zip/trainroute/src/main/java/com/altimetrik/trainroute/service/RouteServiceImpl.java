package com.altimetrik.trainroute.service;


import com.altimetrik.trainroute.exception.RouteIdNotExistsException;
import com.altimetrik.trainroute.model.Route;
import com.altimetrik.trainroute.repository.RouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RouteServiceImpl implements RouteService {
    @Autowired
    private RouteRepository routeRepository;

    @Override
    public Route addRoute(Route route) {
        return routeRepository.save(route);
    }

    @Override
    public List<Route> getAllRoute() {
        return routeRepository.findAll();
    }

    @Override
    public Route getRouteById(int routeId) throws RouteIdNotExistsException {
        Optional<Route> pro=routeRepository.findById(routeId);

        if(pro.isEmpty()){
            throw new RouteIdNotExistsException("Route is not exists in the db!!! check the route ID");
        }

        return pro.get();
    }

    @Override
    public Route updateRoute(Route route) throws RouteIdNotExistsException {
        if(getRouteById(route.getRouteId())!=null) {
            return routeRepository.save(route);
        }
        return null;
    }

    @Override
    public String deleteRouteById(int routeId) throws RouteIdNotExistsException {
        String message="Route Does not exists to delete";
        Route r=getRouteById(routeId);
        if(r!=null){
            routeRepository.deleteById(routeId);
            message="Route deleted successfully";
            return message;
        }
        return message;
    }
}
