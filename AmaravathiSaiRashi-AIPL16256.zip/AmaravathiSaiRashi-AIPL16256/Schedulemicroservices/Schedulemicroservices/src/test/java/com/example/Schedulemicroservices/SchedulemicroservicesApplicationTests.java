package com.example.Schedulemicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulemicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
