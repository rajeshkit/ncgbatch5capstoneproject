package com.example.Schedulemicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchedulemicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchedulemicroservicesApplication.class, args);
	}

}
