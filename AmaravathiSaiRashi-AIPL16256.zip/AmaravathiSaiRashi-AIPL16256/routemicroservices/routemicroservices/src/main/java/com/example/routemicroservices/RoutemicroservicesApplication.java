package com.example.routemicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoutemicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoutemicroservicesApplication.class, args);
	}

}
