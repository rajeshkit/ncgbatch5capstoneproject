package com.example.trainbooking.service;

import com.example.trainbooking.entity.Location;

import java.util.List;

public interface ILocationService {
    List<Location> getAllLocations();
}
