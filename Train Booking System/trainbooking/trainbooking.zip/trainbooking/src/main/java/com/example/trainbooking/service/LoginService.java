package com.example.trainbooking.service;
import org.springframework.stereotype.Service;

@Service
public class LoginService implements ILoginService {

}
