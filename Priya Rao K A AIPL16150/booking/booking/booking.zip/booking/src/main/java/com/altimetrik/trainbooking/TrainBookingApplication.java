package com.altimetrik.trainbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainBookingApplication {

    public static void main(String[] args) {SpringApplication.run(TrainBookingApplication.class, args);
    }


}