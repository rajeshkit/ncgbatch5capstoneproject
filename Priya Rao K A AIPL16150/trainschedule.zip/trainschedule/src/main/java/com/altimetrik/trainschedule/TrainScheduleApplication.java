package com.altimetrik.trainschedule;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainScheduleApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrainScheduleApplication.class, args);
    }

}
