package com.altimetrik.trainroute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainRouteApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrainRouteApplication.class, args);
    }

}
