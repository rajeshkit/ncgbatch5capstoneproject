package com.altimetrik.trainbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainBookingApplicationTest {

    @Test
    void contextLoads() {
    }

}